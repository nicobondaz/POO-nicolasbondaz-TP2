package ar.org.centro8.curso.java.concesionaria.entidades;



import lombok.Getter;

@Getter
public class Auto extends Vehiculo {

    private int puertas;

    //constructor que incluye el atributo puertas
    public Auto(String marca, String modelo, int puertas, double precio) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

 
    //sobreescribo el metodo toString() para que se muestre como quiero
    @Override
     public String toString() {
        return "Marca: " + getMarca()+" // Modelo: " + getModelo()+ " // Puertas: " + puertas + " // Precio: " + FORMATO.format(getPrecio());
    }

}

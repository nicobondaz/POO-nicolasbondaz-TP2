package ar.org.centro8.curso.java.concesionaria.entidades;

import java.text.DecimalFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public abstract class Vehiculo implements Comparable<Vehiculo> {


private String marca;
private String modelo;
private Double precio;


//DecimalFormat ayuda a mostrar números con un formato que le indiquemos, separando miles y decimales
public static final DecimalFormat FORMATO = new DecimalFormat("$###,###.00");
	


//  Este metodo permite comparar dos objetos de vehiculo para poder obtener su orden natural
@Override
public int compareTo(Vehiculo otro) {
    int cmpMarca = this.marca.compareTo(otro.marca);
    if (cmpMarca != 0) return cmpMarca;

    int cmpModelo = this.modelo.compareTo(otro.modelo);
    if (cmpModelo != 0) return cmpModelo;

    return Double.compare(this.precio, otro.precio); 
}






}

package ar.org.centro8.curso.java.testsConcesionaria;

import ar.org.centro8.curso.java.concesionaria.utilsConcesionaria.MetodosConcesionaria;

public class TestsConsesionaria {
    public static void main(String[] args) {
        
           MetodosConcesionaria servicio = new MetodosConcesionaria();

        // Cargar los vehículos
        servicio.cargarVehiculos();

        // Mostrar los datos por consola
        servicio.mostrarDatos();
        
      
    }
}

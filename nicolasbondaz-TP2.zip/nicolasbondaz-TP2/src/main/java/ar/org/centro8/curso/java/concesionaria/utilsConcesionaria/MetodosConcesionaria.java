package ar.org.centro8.curso.java.concesionaria.utilsConcesionaria;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


// Importar las clases Vehiculo, Auto y Moto
import ar.org.centro8.curso.java.concesionaria.entidades.Vehiculo;
import ar.org.centro8.curso.java.concesionaria.entidades.Auto;
import ar.org.centro8.curso.java.concesionaria.entidades.Moto;


    public class MetodosConcesionaria {

    public List<Vehiculo> vehiculos = new ArrayList<>();

    //este  método carga los vehículos en la lista vehiculos mediante el metodo add()
    // de la clase ArrayList
     public void cargarVehiculos() {
        vehiculos.add(new Auto("Peugeot", "206", 4, 200000));
        vehiculos.add(new Moto("Honda", "Titan", "125c", 60000));
        vehiculos.add(new Auto("Peugeot", "208", 5, 250000));
        vehiculos.add(new Moto("Yamaha", "YBR", "160c", 80500.50));
    }

    // Este metodo muestra todos los vehiculos
    public void mostrarVehiculos(){
         vehiculos.forEach(System.out::println);
    }

    // Este método muestra el vehículo más caro y el más barato de la lista vehiculos
     public void mostrarVehiculoMasCaroYMasBarato() {
        System.out.println("=============================");
        Vehiculo masCaro = Collections.max(vehiculos);
        Vehiculo masBarato = Collections.min(vehiculos);

        System.out.println("Vehículo más caro: " + masCaro.getMarca() + " " + masCaro.getModelo());
        System.out.println("Vehículo más barato: " + masBarato.getMarca() + " " + masBarato.getModelo());
    }


    // Este método muestra el primer vehículo que contenga la letra 'Y' en su modelo
     public void mostrarVehiculoConLetraY() {
        for (Vehiculo v : vehiculos) {
            if (v.getModelo().contains("Y")) {
                System.out.println("Vehículo que contiene en el modelo la letra 'Y': " +
                        v.getMarca() + " " + v.getModelo() + " $" + Vehiculo.FORMATO.format(v.getPrecio())
                );
            }
        }
    }

    // Este método muestra los vehículos ordenados por precio de mayor a menor pasandolo por un stream para no alterar la lista original
      public void mostrarOrdenadosPorPrecioDesc() {
    System.out.println("=============================");
    System.out.println("Vehículos ordenados por precio de mayor a menor:");

    vehiculos.stream()
        .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed()) 
        .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));
    }

    // Este método muestra los vehículos ordenados por su orden natural definido en el método compareTo de la clase Vehiculo.
    public void mostrarOrdenNatural() {
        System.out.println("=============================");
        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
        List<Vehiculo> listaNatural = new ArrayList<>(vehiculos);
        Collections.sort(listaNatural);
        for (Vehiculo v : listaNatural) {
            System.out.println(v);
        }
    }

    // Este metodo ejecuta todos los metodos anteriores para mostrar los datos por consola en el test
    public void mostrarDatos() {
        mostrarVehiculos();
        mostrarVehiculoMasCaroYMasBarato();
        mostrarVehiculoConLetraY();
        mostrarOrdenadosPorPrecioDesc();
        mostrarOrdenNatural();
    }


}
